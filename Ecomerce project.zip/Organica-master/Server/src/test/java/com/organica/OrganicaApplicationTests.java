package com.organica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrganicaApplicationTests {

	@Test
	void contextLoads() {
	}

}
